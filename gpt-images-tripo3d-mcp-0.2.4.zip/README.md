# Local MCP helper

Chrome extension: GPT Images to Tripo3d. Helper version: 0.2.4.

## Setup

1. Install extension from Chrome Web Store. Keep Chrome running.
2. Install Node.js 20 or newer. Use local MCP client with initialize-based stdio support.
3. Extract this helper ZIP into a permanent directory.
4. Create output directory. Set existing absolute path as RUNNER_OUTPUT_DIR.
5. Add client configuration below. Replace helper path and output path.
6. Start client. Extension discovers helper within 30 seconds and opens control tab.
7. Sign in to ChatGPT for images. Sign in to Tripo only for models.

```json
{
  "mcpServers": {
    "image-runner": {
      "command": "node",
      "args": ["/absolute/path/to/mcp-helper/mcp/server.js"],
      "env": {
        "RUNNER_EXTENSION_ID": "djfphefibidgmijemkjghanogobjnfno",
        "RUNNER_OUTPUT_DIR": "/absolute/path/to/output"
      }
    }
  }
}
```

No dependency installation required. Use absolute Node executable path if client cannot find node.

Default port: 17321. Keep default for automatic browser connection. Optional RUNNER_MCP_PORT changes port; then select matching port and Connect in dashboard. Optional RUNNER_MCP_TOKEN sets token, minimum 32 characters. Otherwise helper generates process token.

MCP versions: initialize-based 2025-06-18, 2025-03-26, 2024-11-05.

## Commands

- runner_status: queues, settings, folder, available service tabs. offset/limit pagination; default 25, maximum 50.
- runner_open_tab: open ChatGPT or Studio. queue: gpt or tripo.
- runner_select_tab: select existing service tab.
- runner_add_prompts: append exact prompt strings; no send yet.
- runner_start: start or resume queue. Accepted means asynchronous startup; inspect status for result.
- runner_stop: stop after current image or model.
- runner_settings: Tripo credit ceiling, model limit, watch. limit 0 means unlimited.
- runner_rescan: rescan idle output directory.
- runner_clear_finished: remove saved/failed GPT records; retain files.
- runner_prompt_action: explicit retry/remove by item ID. Retry permits another send.

GPT-only: open ChatGPT, add prompts, start gpt queue. No Studio tab required. Images save directly in RUNNER_OUTPUT_DIR.

Models: open Studio, choose generation settings there, start tripo queue. Generation can consume credits. Existing credit ceiling remains enforced.

Uncertain submissions never resend automatically. Inspect state before retrying timed-out commands. Existing model binding, explicit Tripo regeneration and manual FBX import remain browser recovery actions.

## Local data

Helper binds 127.0.0.1. Configured extension identity and process token required. Folder scope: configured directory only; symlinks rejected. Close writes through temporary files and atomic replacement. Keep .tripo-runner recovery records.

Chosen MCP client receives requested prompts, queue state, filenames and service-tab metadata. Client or model provider may retain or process received data under its own terms. Extension/helper has no developer backend, analytics or telemetry.

Installation, extension updates, service sign-in and some recovery actions require browser interaction. Keep control tab and needed service tabs open during runs. Stop helper by closing its MCP client session. No live generation guarantee; service interfaces can change.

Support: https://github.com/multipliedtwice/gpt-images-tripo3d/issues
Privacy: https://multipliedtwice.github.io/gpt-images-tripo3d/privacy.html
