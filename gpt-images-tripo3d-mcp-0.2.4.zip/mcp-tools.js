const object = properties => ({ type: "object", properties, additionalProperties: false });
const integer = (minimum, maximum) => ({ type: "integer", minimum, maximum });
const queue = { type: "string", enum: ["gpt", "tripo"] };
export const TOOLS = [
  { name: "runner_status", description: "Read actual queue state, folder grant, settings and available browser tabs. Runs continue asynchronously.", inputSchema: object({ offset: integer(0, 1000000), limit: integer(1, 50) }) },
  { name: "runner_open_tab", description: "Open ChatGPT or Tripo Studio for an idle queue using a fixed service URL. Uses existing browser sign-in.", inputSchema: { ...object({ queue }), required: ["queue"] } },
  { name: "runner_add_prompts", description: "Append exact image prompts to GPT queue; does not send them.", inputSchema: { ...object({ prompts: { type: "array", minItems: 1, maxItems: 100, items: { type: "string", minLength: 1, maxLength: 20000 } } }), required: ["prompts"] } },
  { name: "runner_start", description: "Start or resume a queue. May send prompts or spend Studio credits within configured ceiling. Returns accepted after startup, not completion. Never automatically resends uncertain work.", inputSchema: { ...object({ queue }), required: ["queue"] } },
  { name: "runner_stop", description: "Request stop after current image or model; does not cancel generation.", inputSchema: { ...object({ queue }), required: ["queue"] } },
  { name: "runner_rescan", description: "Rescan selected folder while Tripo queue is idle.", inputSchema: object({}) },
  { name: "runner_settings", description: "Update Tripo limits while idle. limit=0 means unlimited. watch keeps waiting for root images.", inputSchema: { ...object({ maxCredits: integer(1, 10000), limit: integer(0, 100000), watch: { type: "boolean" } }), minProperties: 1 } },
  { name: "runner_select_tab", description: "Select an existing signed-in ChatGPT or Studio tab for an idle queue.", inputSchema: { ...object({ queue, tabId: integer(1, Number.MAX_SAFE_INTEGER) }), required: ["queue", "tabId"] } },
  { name: "runner_clear_finished", description: "Remove saved and failed GPT queue records; keeps image files.", inputSchema: object({}) },
  { name: "runner_prompt_action", description: "Explicitly retry or remove one GPT prompt while idle. retry resets to pending and permits sending again on next start; may duplicate a previously submitted prompt.", inputSchema: { ...object({ id: { type: "string", minLength: 1, maxLength: 100 }, action: { type: "string", enum: ["retry", "remove"] } }), required: ["id", "action"] } }
];
const valid = (value, schema) => {
  if (schema.enum && !schema.enum.includes(value)) return false;
  if (schema.type === "object") return value !== null && typeof value === "object" && !Array.isArray(value) && Object.keys(value).every(key => schema.properties[key] && valid(value[key], schema.properties[key])) && (schema.required || []).every(key => Object.hasOwn(value, key)) && Object.keys(value).length >= (schema.minProperties || 0);
  if (schema.type === "array") return Array.isArray(value) && value.length >= schema.minItems && value.length <= schema.maxItems && value.every(item => valid(item, schema.items));
  if (schema.type === "string") return typeof value === "string" && value.trim().length >= (schema.minLength || 0) && value.length <= (schema.maxLength || Infinity);
  if (schema.type === "integer") return Number.isSafeInteger(value) && value >= schema.minimum && value <= schema.maximum;
  return typeof value === schema.type;
};
export const validateTool = (name, args) => {
  const tool = TOOLS.find(tool => tool.name === name);
  if (!tool) throw new Error(`Unknown tool: ${name}`);
  if (!valid(args, tool.inputSchema)) throw new Error(`Invalid arguments for ${name}. See tools/list schema.`);
  return tool;
};
